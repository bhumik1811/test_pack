from setuptools import setup

setup(name='test_package',
      description='Testing installation of Package',
      packages=['test_package'],
      zip_safe=False)
