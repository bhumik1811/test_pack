def emp_name(firstname="", lastname=""):
    print("Employee name:-", firstname.capitalize(), lastname.capitalize())


def emp_department(deptname="", grade=""):
    print("Department name:", deptname.capitalize())
    print("Grade", grade)
